using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class startEndPoint : MonoBehaviour
{
    public Transform startPos;
    public Transform endPos;

    private int LayerIgnoreRaycast;
    // private bool startselectd = true; 
    // private bool endselectd = false; 
    // Start is called before the first frame update
    void Start()
    { 
        LayerIgnoreRaycast = LayerMask.NameToLayer("UnWaklable");

    }

    // Update is called once per frame
    void Update()
    {
        Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if(Input.GetKeyDown(KeyCode.Mouse0))
        {
            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider.transform.gameObject.layer == LayerIgnoreRaycast)
                {
                    return;
                }
                
                startPos.position = hit.point;

            }

        }
        if(Input.GetKeyDown(KeyCode.Mouse1))
        {
            if (Physics.Raycast(ray, out hit))
            {
                if (hit.collider.transform.gameObject.layer == LayerIgnoreRaycast)
                {
                    return;
                }

                endPos.position = hit.point;

            }

        }
        

    }
}
