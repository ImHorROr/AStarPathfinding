﻿using System;
using System.Collections.Generic;
using UnityEngine;
using System.Diagnostics;
using TMPro;

public class AStarPathFinding : MonoBehaviour
{
	Grid grid;
	public Transform player;
	public Transform target;
	public TextMeshProUGUI text;
	protected void Awake()
	{
		grid = GetComponent<Grid>();
	}
	void FindPath(Vector3 startPos, Vector3 targetPos)
	{
		Stopwatch sw = new Stopwatch();
		sw.Start();
		Heap<Node> openSet = new Heap<Node>(grid.MaxSize);
		HashSet<Node> closedSet = new HashSet<Node>();
		Node startNode = grid.NodeFromWorldPoint(startPos);
		openSet.Add(startNode);

		Node endNode = grid.NodeFromWorldPoint(targetPos);

		while (openSet.Count > 0)
		{
			Node currentNode = openSet.RemoveFirst();
			closedSet.Add(currentNode);
			
			if (currentNode == endNode)
			{
				text.text = $"Path Found In {sw.Elapsed.TotalMilliseconds} ms";
				RetractPath(startNode, endNode);
				grid.showPath();
				return;
			}

			foreach (Node neighbour in grid.GetNeighboursNodes(currentNode))
			{
				if (!neighbour.walkable || closedSet.Contains(neighbour))
				{
					continue;
				}

				int newMovementCostToNeighbour = currentNode.gCost + GetDistance(currentNode, neighbour);
				if (newMovementCostToNeighbour < neighbour.gCost || !openSet.Contains(neighbour))
				{
					neighbour.gCost = newMovementCostToNeighbour;
					neighbour.hCost = GetDistance(neighbour, endNode);
					neighbour.parent = currentNode;

					if (!openSet.Contains(neighbour))
						openSet.Add(neighbour);
					else
					{
						//openSet.UpdateItem(neighbour);
					}
				}
			}
		}
	}
	
	int GetDistance(Node a, Node b) 
	{
		int dstX = Mathf.Abs(a.gridX - b.gridX);
		int dstY = Mathf.Abs(a.gridY - b.gridY);
		if(dstX > dstY)
		{
			return 14 * dstY + 10*(dstX - dstY);
		}
		return 14* dstX + 10*(dstY - dstX);
	}
	
	void RetractPath(Node startNode , Node endNode)
	{
		List<Node> path = new	List<Node>();
		Node currentNode = endNode;
		
		while (currentNode !=  startNode)
		{
			path.Add(currentNode);
			currentNode=  currentNode.parent;
		}
		path.Reverse();
		grid.path = path;
	}
	
    // Update is called once per frame
    void Update()
    {
		if (Input.GetKeyDown(KeyCode.Space))
		{
			FindPath(player.position, target.position);
		}
    }
}
